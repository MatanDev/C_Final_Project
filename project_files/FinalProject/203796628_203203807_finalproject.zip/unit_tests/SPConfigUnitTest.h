#ifndef SPCONFIGUNITTEST_H_
#define SPCONFIGUNITTEST_H_

void runConfigTests();

#endif /* SPCONFIGUNITTEST_H_ */
