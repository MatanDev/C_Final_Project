#ifndef SPPOINTUNITTEST_H_
#define SPPOINTUNITTEST_H_


void runPointTests();


#endif /* SPPOINTUNITTEST_H_ */
