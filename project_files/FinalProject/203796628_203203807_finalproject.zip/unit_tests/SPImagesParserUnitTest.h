/*
 * SPImagesParserParserUnitTest.h
 *
 *  Created on: 2 ���� 2016
 *      Author: Matan
 */

#ifndef SPIMAGESPARSERUNITTEST_H_
#define SPIMAGESPARSERUNITTEST_H_

void runImagesParserTests(SPConfig config);

#endif /* SPIMAGESPARSERPARSERUNITTEST_H_ */
